#include <iostream>
using namespace std;

int main() {
	string a = "ajkshd";

	for (char b : a) {
		cout << a[b];
	}
}
