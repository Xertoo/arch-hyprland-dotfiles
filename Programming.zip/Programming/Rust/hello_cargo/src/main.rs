fn main() {
    let a: u8 = 3;
    println!("{}", a);
    println!("Hello, world!");
    println!("{}", a);
}
