#include <iostream>
#include <string>
#include <cmath>

int main() {
    return 0;
}
