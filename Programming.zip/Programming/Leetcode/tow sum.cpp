class Solution {
public:
    vector<int> twoSum(vector<int>& nums, int target) {
        
        unordered_map<int, int> m;                      // Make map

        for (int i = 0; i < nums.size(); i++) {         // It. through vector 'nums'
            int d = target - nums[i];                   // Make variable which is x in: target = x + nums[i]
            if (m.count(d)) { return {i, m[d]}; }       /* If --^ exists in map, return the index value of it and 
                                                        the one that adds to make it same value as target*/

            m[nums[i]] = i;                             // Add nums[i] value to map
        }
        return {};                                      // Return nothing if no combinations make target
    }
};