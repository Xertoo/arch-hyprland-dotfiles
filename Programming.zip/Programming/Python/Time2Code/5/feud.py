# Feud program

# -------------------------
# Subprograms
# -------------------------
def forage_herb(hc):
	herbs = ["dandelion", "burdock", "pipewort", "ragwort", "snapdragon", "toadflex"]

	looking = input("what herb looking for: ")
	looking = looking.lower()

	if looking in herbs:
		print("found.")
		hc.append(looking)

		return hc;
	else:
		print("not found")
		return;


def cauldron(spell, hc, sb):
	if spell == "teleport":
		if ("dandelion" in hc) and ("burdock" in hc):
			sb.append("teleport")
			print("added")
			return sb
		else:
			print("not eough materials")

	if spell == "protect":
		if ("pipewort" in hc) and ("ragwort" in hc):
			sb.append("teleport")
			print("added")
			return sb
		else:
			print("not eough materials")

	if spell == "sprites":
		if ("snapdragon" in hc) and ("toadflex" in hc):
			sb.append("teleport")
			print("added")
			return sb
		else:
			print("not eough materials")


def brew_spell(hc, sb):
	spells = ["teleport", "protect", "sprites"]

	spell = input("which spell? ")
	spell = spell.lower()

	cauldron(spell, hc, sb)

        
def cast_spell(hc, sb):
	spell = input("enter spell: ")

	if spell in sb:
		print("casted", spell)
	else:
		print("dont have spell")


def take_action(hc, sb):
	choice = input("Forage herb, brew or cast a spell? f/b/c : ")

	if choice == 'f':
		hc = forage_herb(hc)

	elif choice == 'b':
		sb = brew_spell(hc, sb)

	elif choice == 'c':
		cast_spell(hc, sb)


# -------------------------
# Main program
# -------------------------
hc = []
sb = []

while True:
	take_action(hc, sb);





