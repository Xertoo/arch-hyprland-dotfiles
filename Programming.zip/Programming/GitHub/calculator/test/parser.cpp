#include <iostream>
#include <string>
#include <sstream>
#include <stack>
#include <cctype>
#include <unordered_map>

string countUp

double parser(unordered_map<string, double> v, string eq) {
	
	for (int i = 0; i < eq.size(); i++) {

		if (eq[i] == '(') {}
	}

}

int main() {

}
