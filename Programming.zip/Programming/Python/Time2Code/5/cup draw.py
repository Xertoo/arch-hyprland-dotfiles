import random

teams = []
been_called = []
t = 0

while True:
	teams.append(input("enter team: "))

	if len(teams)-1 == '': teams.append("bye"); 
	teams.append(input("enter team: "))
	yn = input("continue to add 2 more teams? (y/n): ")

	if yn != 'y':
		break

random.shuffle(teams)

if len(teams) % 2 == 1:
	teams.append("bye")

i = 0

while (i <= int(len(teams)/2)):
	print(teams[i], "vs", teams[i+1])
	#print(i, i + 1)
	i += 2
